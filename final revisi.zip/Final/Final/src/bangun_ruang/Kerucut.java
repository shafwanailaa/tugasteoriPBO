package bangun_ruang;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shafw
 */
public class Kerucut extends Abstract{
    int jarijari = 3;
    int tinggi = 8;
    int sisi = 12;
    double phi = 3.14;
    
    public int volume(){
        return (int)phi*jarijari*jarijari*jarijari*tinggi/3;
    }
    
    public int luasPermukaan(){
        return (int)phi*jarijari*(jarijari*sisi);
    }
}
