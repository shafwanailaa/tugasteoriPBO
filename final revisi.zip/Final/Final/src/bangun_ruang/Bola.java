package bangun_ruang;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shafw
 */
public class Bola extends Abstract {
    int jarijari = 7;
    double phi = 3.14;
    
    @Override
    public int volume(){
        return (int)phi*jarijari*jarijari*jarijari*4/3;
    }
    

    @Override
    public int luasPermukaan() {
        return (int)phi*jarijari*jarijari*4;
    }
}
