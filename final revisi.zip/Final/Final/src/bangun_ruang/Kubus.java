package bangun_ruang;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shafw
 */
public class Kubus extends Abstract {
    int sisi = 4;
    
    public int volume(){
        return sisi*sisi*sisi;
    }
    
    public int luasPermukaan(){
        return 6*sisi*sisi;
    }
}
