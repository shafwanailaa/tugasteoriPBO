package bangun_ruang;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shafw
 */
public abstract class Abstract {
    public abstract int volume();
    public abstract int luasPermukaan();
    
    public int getVolume(){
        return volume();
    }
    
    public int getLuasPermukaan(){
        return luasPermukaan();
    }
}
