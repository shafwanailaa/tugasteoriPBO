package bangun_datar;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shafw
 */
public class persegipanjang extends Bangundatar {
    int panjang = 8;
    double lebar = 3;
    
    void hitungLuas() {
        System.out.println(panjang*lebar);
    }
    
    void hitungKeliling(){
        System.out.println(2*panjang*lebar);
    }
}
