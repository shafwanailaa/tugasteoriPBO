package bangun_datar;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shafw
 */
public class lingkaran extends Bangundatar{
    double phi = 3.14;
    double jarijari = 14;
    
    void hitungLuas() {
        System.out.println(phi*(jarijari*jarijari));
    }
    
    void hitungKeliling() {
        System.out.println(2*phi*jarijari);
    }
}
