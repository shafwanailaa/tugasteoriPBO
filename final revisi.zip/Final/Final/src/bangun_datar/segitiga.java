package bangun_datar;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shafw
 */
public class segitiga extends Bangundatar{
    double alas = 9;
    double tinggi = 12;
    double sisimiring = 4;
    
    void hitungLuas(){
        System.out.println(tinggi*alas/2);
    }
    
    void hitungKeliling(){
        System.out.println(alas+sisimiring+sisimiring);
    }
}
