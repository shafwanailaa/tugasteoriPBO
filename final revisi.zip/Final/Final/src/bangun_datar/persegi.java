package bangun_datar;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shafw
 */
public class persegi extends Bangundatar{
    double sisi = 6;
    
    void hitungLuas() {
        System.out.println(sisi*sisi) ;
    }
    
    void hitungKeliling() {
        System.out.println(4*sisi);
    }
}
