/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metode_pembayaran;

/**
 *
 * @author shafw
 */
public class pembayaranbelanja implements metodebayarpakaiaplikasi {
    double kembalian;

    @Override
    public double bayarGopay(double saldo, double belanjatotal) {
        kembalian = saldo-belanjatotal;
        return kembalian;
    }

    @Override
    public double bayarShopee(double saldo, double belanjatotal) {
        kembalian = saldo-belanjatotal;
        return kembalian;
    }

    @Override
    public double bayarCash(double cash, double belanja) {
        kembalian = cash-belanja;
        return kembalian;
    }

    @Override
    public double bayarQris(double saldo, double belanjatotal) {
        kembalian = saldo-belanjatotal;
        return kembalian;
    }

    @Override
    public double bayarEwallet(double saldo, double belanjatotal) {
        kembalian = saldo-belanjatotal;
        return kembalian;
    }

    @Override
    public double bayarCreditCard(double saldo, double belanjatotal) {
        kembalian = saldo-belanjatotal;
        return kembalian;
    }

    @Override
    public double bayarDebitCard(double saldo, double belanjatotal) {
        kembalian = saldo-belanjatotal;
        return kembalian;
    }
}
