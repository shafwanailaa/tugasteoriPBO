/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metode_pembayaran;

/**
 *
 * @author shafw
 */
public interface metodebayar {
    public double bayarCash(double cash, double belanja);
    public double bayarQris(double saldo, double belanjatotal);
    public double bayarEwallet(double saldo, double belanjatotal);
    public double bayarCreditCard(double saldo, double belanjatotal);
    public double bayarDebitCard(double saldo, double belanjatotal);
}
