/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugaskelompok;

/**
 *
 * @author shafw
 */
public class mainclass extends pembayaranbelanja {
    public static void main(String[] args) {
        pembayaranbelanja pb = new pembayaranbelanja();
        pb.bayarCash(50000, 1000);
        System.out.println("kembalian pembayaran cash: Rp. " + pb.kembalian);
        
        pembayaranbelanja pp = new pembayaranbelanja();
        pp.bayarCreditCard(2000000, 200200);
        System.out.println("\nkembalian pembayaran credit card: Rp." + pp.kembalian);
        
        pembayaranbelanja qq = new pembayaranbelanja();
        qq.bayarDebitCard(4000000, 123000);
        System.out.println("\nkembalian pembayaran debit card: Rp." +qq.kembalian);

        pembayaranbelanja oo = new pembayaranbelanja();
        oo.bayarEwallet(10000000, 550000);
        System.out.println("\nkembalian pembayaran Ewallet: Rp." +oo.kembalian);
        
        pembayaranbelanja ll = new pembayaranbelanja();
        ll.bayarGopay(20000, 15000);
        System.out.println("\nkembalian pembayaran gopay: Rp." +ll.kembalian);
        
        pembayaranbelanja ss = new pembayaranbelanja();
        ss.bayarQris(7000000, 22000);
        System.out.println("\nkembalian pembayaran Qris: Rp." +ss.kembalian);
        
        pembayaranbelanja gg = new pembayaranbelanja();
        gg.bayarShopee(300000, 25000);
        System.out.println("\nkembalian pembayaran Shopeepay: Rp." +gg.kembalian);
    }
    
}
